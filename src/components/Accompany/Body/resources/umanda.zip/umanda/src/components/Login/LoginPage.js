import React from "react";
import LoginMain from "./LoginMain";

function LoginPage() {
  return (
    <>
      <LoginMain />
    </>
  );
}

export default LoginPage;
