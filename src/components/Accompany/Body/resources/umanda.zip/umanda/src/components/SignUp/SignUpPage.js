import React from "react";
import SignUpMain from "./SignUpMain";

function SignUpPage() {
  return (
    <>
      <SignUpMain />
    </>
  );
}

export default SignUpPage;
