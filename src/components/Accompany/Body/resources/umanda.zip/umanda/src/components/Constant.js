export const API_HOST = process.env.REACT_APP_API_HOST;
export const FetchStatus = {
  Request: "Request",
  Sucess: "Success",
  Fail: "Fail",
};
